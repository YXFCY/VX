海哥拦截规则

不定时更新

不再更新hg.txt文件，请使用hg1.txt文件

复制链接 https://raw.githubusercontent.com/2771936993/HG/main/hg1.txt

gitee仓库链接：https://gitee.com/hgzsg_admin/HG.git
